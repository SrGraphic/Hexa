// FUNCION LOGICA PARA ARRANCAR CALENDARIO

let currentWeek = 0;

const monthDisplay = document.getElementById("monthDisplay");
const dayElements = [
    document.getElementById("day1"),
    document.getElementById("day2"),
    document.getElementById("day3"),
    document.getElementById("day4"),
    document.getElementById("day5")
];

function updateCalendar() {
    const today = new Date();
    today.setDate(today.getDate() + currentWeek * 7);

    // Obtener el lunes de la semana actual
    const dayOfWeek = today.getDay();
    const monday = new Date(today);
    monday.setDate(today.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1)); // Ajuste si hoy es domingo

    // Actualizar el mes
    const options = { month: "long", year: "numeric" };
    monthDisplay.textContent = monday.toLocaleDateString("es-ES", options);

    // Actualizar los días de la semana
    for (let i = 0; i < 5; i++) {
        const currentDay = new Date(monday);
        currentDay.setDate(monday.getDate() + i);
        dayElements[i].textContent = currentDay.getDate();
    }
}

function changeWeek(direction) {
    currentWeek += direction;
    updateCalendar();
}

let selectedCell = null;

const modal = document.getElementById("modal");
const modalText = document.getElementById("modalText");
const saveBtn = document.getElementById("saveBtn");
const deleteBtn = document.getElementById("deleteBtn");
const closeBtn = document.getElementById("closeBtn");

// Abrir modal al hacer clic en una celda (excepto la de la hora)
document.querySelectorAll("tbody td").forEach(cell => {
    cell.addEventListener("click", () => {
        // Ignorar la primera columna (hora)
        if (cell.cellIndex === 0) return;

        selectedCell = cell;
        modalText.value = cell.textContent.trim();
        modal.style.display = "block";
        modalText.focus();
    });
});

// Guardar texto
saveBtn.addEventListener("click", () => {
    if (selectedCell) {
        selectedCell.textContent = modalText.value.trim();
    }
    modal.style.display = "none";
});

// Eliminar texto
deleteBtn.addEventListener("click", () => {
    if (selectedCell) {
        selectedCell.textContent = "";
    }
    modal.style.display = "none";
});

// Cerrar modal
closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
});


updateCalendar(); // Inicializar con la fecha actual