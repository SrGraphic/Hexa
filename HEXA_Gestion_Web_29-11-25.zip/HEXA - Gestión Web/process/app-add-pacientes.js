// CREAR NUEVO PACIENTE //
document.getElementById('addPatientForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const nombre = document.getElementById('input_name').value;
    const apellidos = document.getElementById('input_subname').value;
    const genero = document.getElementById('genero').value;
    const email = document.getElementById('input_email').value;
    const telefono = document.getElementById('input_phone').value;
    const telefono_2 = document.getElementById('input_phone_2').value;
    const fechaNacimiento = document.getElementById('input_date').value;
    const direccion = document.getElementById('input_address').value;
    const localidad = document.getElementById('input_locality').value;
    const alergias = document.getElementById('alergias').value;
    const medicacion_actual = document.getElementById("medicacion_actual").value;
    const enfermedades_cronicas = document.getElementById("enfermedades_cronicas").value;
    const cirugias_previas = document.getElementById("cirugias_previas").value;
    const vacunas_recientes = document.getElementById("vacunas_recientes").value;
    const antecedentes_familiares = document.getElementById("antecedentes_familiares").value;


    const newPatient = {
        nombre: nombre,
        apellidos: apellidos,
        genero: genero,
        email: email,
        telefono: telefono,
        telefono_2: telefono_2,
        fecha_nacimiento: fechaNacimiento,
        direccion: direccion,
        localidad: localidad,
        alergias: alergias,
        medicacion_actual: medicacion_actual,
        enfermedades_cronicas: enfermedades_cronicas,
        cirugias_previas: cirugias_previas,
        vacunas_recientes: vacunas_recientes,
        antecedentes_familiares: antecedentes_familiares
    };

    fetch('http://localhost:4000/pacientes', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newPatient)
    })
        .then(response => response.json())
        .then(data => {
            console.log('Nuevo paciente añadido:', data);
            alert('El paciente ha sido añadido con éxito.');
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Hubo un problema al añadir el paciente.');
        });
});

// SELECCION DE GÉNERO //
function changeImage() {
    const genderSelect = document.getElementById('genero');
    const genderImage = document.getElementById('genderImage');
    const selectedGender = genderSelect.value;

    if (selectedGender === 'hombre') {
        genderImage.src = '../assets/hombre.png';
    } else if (selectedGender === 'mujer') {
        genderImage.src = '../assets/mujer_2.png';
    };
};