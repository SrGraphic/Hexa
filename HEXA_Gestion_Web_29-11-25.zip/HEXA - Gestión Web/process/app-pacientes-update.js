function changeImage() {
  const genderSelect = document.getElementById('genero');
  const genderImage = document.getElementById('genderImage');
  const selectedGender = genderSelect.value.trim();

  if (selectedGender === 'hombre') {
    genderImage.src = '../assets/hombre.png';
  } else if (selectedGender === 'mujer') {
    genderImage.src = '../assets/mujer.png';
  } else if (selectedGender === 'otro') {
    genderImage.src = '../assets/otro.png';
  }
}

window.changeImage = changeImage;


// ===== ACTUALIZAR PACIENTE (FIREBASE) ===== //

// IMPORTAR FIREBASE
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import { getFirestore, collection, query, where, getDocs, updateDoc } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCrv2BiybqKcI8cLsm-3qt8u_FgKf-QY8U",
  authDomain: "nexa-db-93fdd.firebaseapp.com",
  projectId: "nexa-db-93fdd",
  storageBucket: "nexa-db-93fdd.appspot.com",
  messagingSenderId: "1011655429895",
  appId: "1:1011655429895:web:cfc1dc4a57776b64febfa2",
  measurementId: "G-EB761FYEX0"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ===== BUSCAR PACIENTE ===== //

document.addEventListener("DOMContentLoaded", async function () {
  const params = new URLSearchParams(window.location.search);
  const pacienteId = Number(params.get("id"));

  if (!pacienteId) {
    alert("No se recibió ID del paciente");
    return;
  }

  const clinicaActual = localStorage.getItem('clinicaConectada');
  const pacientesRef = collection(db, "clinicasID", clinicaActual, "pacientes");

  const q = query(pacientesRef, where("id", "==", pacienteId));

  const querySnapshot = await getDocs(q);

  if (querySnapshot.empty) {
    alert("No existe un paciente con el id " + pacienteId);
    console.log("No encontrado en la colección.");
    return;
  }

  const docSnap = querySnapshot.docs[0];
  const pacienteRef = docSnap.ref;
  const data = docSnap.data();

  // ===== PINTAR FORMULARIO ===== //

  document.getElementById('nombre').value = data.nombre;
  document.getElementById('apellidos').value = data.apellidos;
  document.getElementById('genero').value = data.genero;
  changeImage();
  document.getElementById('email').value = data.email;
  document.getElementById('telefono').value = data.telefono;
  document.getElementById('telefono_2').value = data.telefono_2;
  document.getElementById('fecha_nacimiento').value = convertirFechaAInput(data.fecha_nacimiento);
  document.getElementById('direccion').value = data.direccion;
  document.getElementById('localidad').value = data.localidad;
  document.getElementById('medicacion_actual').value = data.medicacion_actual;
  document.getElementById('observaciones').value = data.observaciones;

  // ===== ACTUALIZAR PACIENTE ===== //

  document.getElementById("formActualizarPaciente").onsubmit = async function (event) {
    event.preventDefault();

    // Conversor de fechas al guardado de firestore
    let fechaInput = document.getElementById('fecha_nacimiento').value; // YYYY-MM-DD
    let [año, mes, dia] = fechaInput.split("-");
    let fechaFormateada = `${dia}-${mes}-${año}`; // DD-MM-YYYY

    const updatedPaciente = {
      nombre: document.getElementById('nombre').value,
      apellidos: document.getElementById('apellidos').value,
      genero: document.getElementById('genero').value,
      email: document.getElementById('email').value,
      telefono: document.getElementById('telefono').value,
      telefono_2: document.getElementById('telefono_2').value,
      fecha_nacimiento: fechaFormateada, // <-- aquí
      direccion: document.getElementById('direccion').value,
      localidad: document.getElementById('localidad').value,
      medicacion_actual: document.getElementById('medicacion_actual').value,
      observaciones: document.getElementById('observaciones').value
    };


    try {
      await updateDoc(pacienteRef, updatedPaciente);
      alert("Paciente actualizado correctamente");

    } catch (error) {
      console.error("Error al actualizar paciente:", error);
      alert("Hubo un problema al actualizar");
    }
  };

  // ===== ACCION RECETAS ===== //

  const btnReceta = document.getElementById("btnReceta");

  btnReceta.addEventListener("click", () => {
    window.location.href = `receta.html?id=${pacienteId}`;
  });

});

// CONVERSION DE FECHA DD-MM-AAAA
function convertirFechaAInput(fechaStr) {
  if (!fechaStr) return "";

  const partes = fechaStr.split("-");
  if (partes.length !== 3) return "";

  const [dia, mes, año] = partes;
  return `${año}-${mes}-${dia}`;
}

// TRANSFORMACION BOTON
const fileInput = document.getElementById('fileInput');
const fileName = document.getElementById('fileName');
const iconWrapper = document.getElementById('iconWrapper');

fileInput.addEventListener('change', () => {
  if (fileInput.files.length > 0) {
    fileName.textContent = fileInput.files[0].name;
    iconWrapper.classList.add('green');
  } else {
    fileName.textContent = "Ningún archivo seleccionado";
    iconWrapper.classList.remove('green');
  }
});