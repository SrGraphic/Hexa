// ===== LOGIN ===== //
const usuario = localStorage.getItem('usuarioConectado');
const clinicaActual = localStorage.getItem('clinicaConectada');

if (!usuario || !clinicaActual) {
    window.location.href = "../index.html";
}

// Conversor de nombres
const nombresClinicas = {
    "clinicaSantaMaria": "&nbsp;CLÍNICA SANTA MARIA",
    "clinicaOctubreMd": "&nbsp;CLÍNICA OCTUBRE MADRID"
};

// Mostrar clínica conectada (estética)
document.getElementById('clinica-info').innerHTML = `
  <i class="fa-solid fa-wifi" style="color: #63E6BE;"></i>
  ${nombresClinicas[clinicaActual] || clinicaActual}
`;

// ===== BUTTON SALIR ===== //
document.getElementById('salir-btn').addEventListener('click', function () {
    document.getElementById('confirmacion-salida').style.display = 'flex';
});

document.getElementById('cerrar-btn').addEventListener('click', function () {
    window.location.href = '../index.html';
});

document.getElementById('mantener-btn').addEventListener('click', function () {
    document.getElementById('confirmacion-salida').style.display = 'none';
});
