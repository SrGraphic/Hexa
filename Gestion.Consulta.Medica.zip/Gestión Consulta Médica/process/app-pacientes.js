// LOADER
window.onload = function () {
    setTimeout(() => {
        document.querySelector(".loader-wrapper").style.display = "none";
        document.getElementById("content").style.display = "block";
    }, 1000);
};

function toggleChat() {
    var chatBox = document.getElementById("chatBox");
    chatBox.style.display = (chatBox.style.display === "block") ? "none" : "block";
}

// TABLA PARA VISIONAR PACIENTES //
fetch('http://localhost:4000/pacientes')
    .then(response => response.json())
    .then(data => displayPatients(data))
    .catch(error => console.error('Error:', error));

function displayPatients(data) {
    const tableBody = document.getElementById('pacienteTableBody');
    tableBody.innerHTML = '';
    const limitedData = data.slice(0, 9); // Límite de 8 filas
    limitedData.forEach(pacientes => {
        const row = document.createElement('tr');
        row.innerHTML = ` 
                <td>${pacientes.id}</td> 
                <td class="marked">${pacientes.nombre}</td> 
                <td>${pacientes.apellidos}</td> 
                <td>${pacientes.fecha_nacimiento}</td> 
                <td>${pacientes.telefono}</td> 
                <td>${pacientes.localidad}</td> 
                <td class="sx"><i class='icons bx bxs-user-rectangle' data-id="${pacientes.id}"></i></td>
            `;
        tableBody.appendChild(row);
    });

    // CONECTOR PARA MODIFICAR EL PACIENTE // 
    const tdElements = document.querySelectorAll('.bxs-user-rectangle');
    tdElements.forEach(td => {
        td.addEventListener('click', function () {
            const pacienteId = td.getAttribute('data-id');
            redirectToUpdatePacientePage(pacienteId);
        });
    });

    document.getElementById('totalResults').textContent = 'Resultados totales: ' + data.length;
}

function redirectToUpdatePacientePage(pacienteId) {
    window.location.href = `actualizar_paciente.html?id=${pacienteId}`;
}

// BARRA DE BÚSQUEDA DE PACIENTES POR NOMBRE //
function searchClient() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();

    fetch('http://localhost:4000/pacientes')
        .then(response => response.json())
        .then(data => {
            const filteredData = data.filter(pacientes =>
                pacientes.nombre.toLowerCase().includes(searchInput) ||
                pacientes.apellidos.toLowerCase().includes(searchInput)
            );
            displayPatients(filteredData);
        }).catch(error => console.error('Error:', error));
}

// CREAR NUEVO PACIENTE //
document.getElementById('addPatientForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const nombre = document.getElementById('input_name').value;
    const apellidos = document.getElementById('input_subname').value;
    const genero = document.getElementById('genero').value;
    const email = document.getElementById('input_email').value;
    const telefono = document.getElementById('input_phone').value;
    const telefono_2 = document.getElementById('input_phone_2').value;
    const fechaNacimiento = document.getElementById('input_date').value;
    const direccion = document.getElementById('input_address').value;
    const localidad = document.getElementById('input_locality').value;
    const alergias = document.getElementById('alergias').value;
    const medicacion_actual = document.getElementById("medicacion_actual").value;
    const enfermedades_cronicas = document.getElementById("enfermedades_cronicas").value;
    const cirugias_previas = document.getElementById("cirugias_previas").value;
    const vacunas_recientes = document.getElementById("vacunas_recientes").value;
    const antecedentes_familiares = document.getElementById("antecedentes_familiares").value;


    const newPatient = {
        nombre: nombre,
        apellidos: apellidos,
        genero: genero,
        email: email,
        telefono: telefono,
        telefono_2: telefono_2,
        fecha_nacimiento: fechaNacimiento,
        direccion: direccion,
        localidad: localidad,
        alergias: alergias,
        medicacion_actual: medicacion_actual,
        enfermedades_cronicas: enfermedades_cronicas,
        cirugias_previas: cirugias_previas,
        vacunas_recientes: vacunas_recientes,
        antecedentes_familiares: antecedentes_familiares
    };

    fetch('http://localhost:4000/pacientes', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newPatient)
    })
        .then(response => response.json())
        .then(data => {
            console.log('Nuevo paciente añadido:', data);
            alert('El paciente ha sido añadido con éxito.');
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Hubo un problema al añadir el paciente.');
        });
});

// SELECCION DE GÉNERO //
function changeImage() {
    const genderSelect = document.getElementById('genero');
    const genderImage = document.getElementById('genderImage');
    const selectedGender = genderSelect.value;

    if (selectedGender === 'hombre') {
        genderImage.src = '../assets/hombre.png';
    } else if (selectedGender === 'mujer') {
        genderImage.src = '../assets/mujer_2.png';
    };
};

// BOTON SALIR FUNCTION
document.getElementById('salir-btn').addEventListener('click', function () {
    document.getElementById('confirmacion-salida').style.display = 'flex';
});

document.getElementById('cerrar-btn').addEventListener('click', function () {
    window.location.href = '../index.html';
});

document.getElementById('mantener-btn').addEventListener('click', function () {
    document.getElementById('confirmacion-salida').style.display = 'none';
});

// PLIEGUE SIDEBAR
function toggleSidebar() {
    document.querySelector('.sidebar').classList.toggle('collapsed');
}