function changeImage() {
    const genderSelect = document.getElementById('genero');
    const genderImage = document.getElementById('genderImage');
    const selectedGender = genderSelect.value;

    if (selectedGender === 'hombre') {
        genderImage.src = '../assets/hombre.png';
    } else if (selectedGender === 'mujer') {
        genderImage.src = '../assets/mujer_2.png';
    };
}

// ---------- ACTUALIZAR PACIENTE ----------- //

document.addEventListener('DOMContentLoaded', function() {
    window.onload = function () {
      const params = new URLSearchParams(window.location.search);
      const pacienteId = params.get('id');
  
      // Cargar los datos del paciente
      fetch(`http://localhost:4000/pacientes/${pacienteId}`)
        .then(response => response.json())
        .then(data => {
          document.getElementById('nombre').value = data.nombre;
          document.getElementById('apellidos').value = data.apellidos;
          document.getElementById('genero').value = data.genero;
          changeImage();
          document.getElementById('email').value = data.email;
          document.getElementById('telefono').value = data.telefono;
          document.getElementById('telefono_2').value = data.telefono_2;
          document.getElementById('fecha_nacimiento').value = data.fecha_nacimiento; // Fecha de nacimiento en formato YYYY-MM-DD
          document.getElementById('direccion').value = data.direccion;
          document.getElementById('localidad').value = data.localidad;
          // ENF
          document.getElementById('alergias').value = data.alergias;
          document.getElementById('medicacion_actual').value = data.medicacion_actual;
          document.getElementById('enfermedades_cronicas').value = data.enfermedades_cronicas;
          document.getElementById('cirugias_previas').value = data.cirugias_previas;
          document.getElementById('vacunas_recientes').value = data.vacunas_recientes;
          document.getElementById('antecedentes_familiares').value = data.antecedentes_familiares;
        });
  
      // Enviar el formulario para actualizar los datos del paciente
      document.getElementById('formActualizarPaciente').onsubmit = function (event) {
        event.preventDefault();
  
        const updatedPaciente = {
          nombre: document.getElementById('nombre').value,
          apellidos: document.getElementById('apellidos').value,
          genero: document.getElementById('genero').value,
          email: document.getElementById('email').value,
          telefono: document.getElementById('telefono').value,
          telefono_2: document.getElementById('telefono_2').value,
          fecha_nacimiento: document.getElementById('fecha_nacimiento').value,
          direccion: document.getElementById('direccion').value,
          localidad: document.getElementById('localidad').value,
          alergias: document.getElementById('alergias').value,
          medicacion_actual: document.getElementById('medicacion_actual').value,
          enfermedades_cronicas: document.getElementById('enfermedades_cronicas').value,
          cirugias_previas: document.getElementById('cirugias_previas').value,
          vacunas_recientes: document.getElementById('vacunas_recientes').value,
          antecedentes_familiares: document.getElementById('antecedentes_familiares').value
        };
  
        fetch(`http://localhost:4000/pacientes/${pacienteId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(updatedPaciente)
        })
          .then(response => response.json())
          .then(data => {
            alert('Paciente actualizado correctamente');
          })
          .catch(error => {
            console.error('Error al actualizar los datos:', error);
            alert('Hubo un problema al actualizar los datos');
          });
      };
      const btnReceta = document.getElementById('btnReceta');

btnReceta.addEventListener('click', () => {
  if (pacienteId) {
    window.location.href = `receta.html?id=${pacienteId}`;
  } else {
    alert("No se ha podido obtener el ID del paciente");
  }
});

    };
  });