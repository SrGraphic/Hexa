document.getElementById('login-form').addEventListener('submit', async function(event) {
  event.preventDefault();

  const usuario = document.getElementById('usuario').value;
  const codigo = document.getElementById('codigo').value;

  try {
    const response = await fetch('http://localhost:4000/usuarios');
    const usuarios = await response.json();

    const usuarioValido = usuarios.find(user => user.usuario === usuario && user.codigo === codigo);

    if (usuarioValido) {
      alert(`¡Inicio de sesión correcto, ${usuario}!`);
      localStorage.setItem('usuarioConectado', usuario); // Almacena el usuario en localStorage
      window.location.href = 'dashboard.html';
    } else {
      alert('Usuario o código incorrectos');
    }
  } catch (error) {
    console.error('Error al conectarse con el servidor JSON:', error);
    alert('Hubo un problema al intentar iniciar sesión');
  }
});

// LOADER 
window.onload = function () {
  setTimeout(() => {
     document.querySelector(".loader-wrapper").style.display = "none";
     document.getElementById("content").style.display = "block";
  }, 2000);
};

function toggleChat() {
  var chatBox = document.getElementById("chatBox");
  chatBox.style.display = (chatBox.style.display === "block") ? "none" : "block";
}