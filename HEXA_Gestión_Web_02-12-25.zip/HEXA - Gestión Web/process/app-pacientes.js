// IMPORTAR FIREBASE
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyCrv2BiybqKcI8cLsm-3qt8u_FgKf-QY8U",
    authDomain: "nexa-db-93fdd.firebaseapp.com",
    projectId: "nexa-db-93fdd",
    storageBucket: "nexa-db-93fdd.appspot.com",
    messagingSenderId: "1011655429895",
    appId: "1:1011655429895:web:cfc1dc4a57776b64febfa2",
    measurementId: "G-EB761FYEX0"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ===== LLAMADA A PACIENTES DE FIREBASE ===== //
const clinicaActual = localStorage.getItem('clinicaConectada');
async function getPacientes() {
    try {
        const querySnapshot = await getDocs(
            collection(db, "clinicasID", clinicaActual, "pacientes")
        );

        const pacientes = querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        pacientes.sort((a, b) => a.id - b.id); // ordenar por ID

        displayPatients(pacientes);

    } catch (error) {
        console.error("Error al obtener pacientes:", error);
    }
}

getPacientes();

// PINTADO TABLA PACIENTES //
function displayPatients(data) {
    const tableBody = document.getElementById('pacienteTableBody');
    tableBody.innerHTML = '';
    const limitedData = data.slice(0, 8); // Límite de 8 filas
    limitedData.forEach(pacientes => {
        const row = document.createElement('tr');
        row.innerHTML = ` 
                <td>${pacientes.id}</td> 
                <td>${pacientes.nombre}</td> 
                <td>${pacientes.apellidos}</td> 
                <td>${pacientes.fecha_nacimiento}</td> 
                <td>${pacientes.telefono}</td> 
                <td>${pacientes.localidad}</td> 
                <td class="sx"><i class='icons fa-solid fa-book' data-id="${pacientes.id}"></i></td>
            `;
        tableBody.appendChild(row);
    });

    // CONECTOR PARA MODIFICAR EL PACIENTE // 
    const tdElements = document.querySelectorAll('.fa-book');
    tdElements.forEach(td => {
        td.addEventListener('click', function () {
            const pacienteId = td.getAttribute('data-id');
            redirectToUpdatePacientePage(pacienteId);
        });
    });

    document.getElementById('totalResults').textContent = 'Resultados totales: ' + data.length;
}

function redirectToUpdatePacientePage(pacienteId) {
    window.location.href = `actualizar_paciente.html?id=${pacienteId}`;
}

// ===== BARRA DE BÚSQUEDA ===== //
window.searchClient = async function () {
    const searchInputEl = document.getElementById('searchInput');
    if (!searchInputEl) return;

    const searchInput = searchInputEl.value.toLowerCase();
    const clinicaActual = localStorage.getItem('clinicaConectada');
    if (!clinicaActual) return;

    try {
        const querySnapshot = await getDocs(
            collection(db, "clinicasID", clinicaActual, "pacientes")
        );

        const pacientes = querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        // Filtros
        const filteredData = pacientes.filter(paciente =>
            paciente.nombre.toLowerCase().includes(searchInput) ||
            paciente.apellidos.toLowerCase().includes(searchInput) ||
            paciente.localidad.toLowerCase().includes(searchInput)
        );

        displayPatients(filteredData);
    } catch (error) {
        console.error("Error al buscar pacientes:", error);
    }
};