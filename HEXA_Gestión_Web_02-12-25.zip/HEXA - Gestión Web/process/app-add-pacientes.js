function changeImage() {
    const genderSelect = document.getElementById('genero');
    const genderImage = document.getElementById('genderImage');
    const selectedGender = genderSelect.value.trim();

    if (selectedGender === 'hombre') {
        genderImage.src = '../assets/hombre.png';
    } else if (selectedGender === 'mujer') {
        genderImage.src = '../assets/mujer.png';
    } else if (selectedGender === 'otro') {
        genderImage.src = '../assets/otro.png';
    }
}

window.changeImage = changeImage;

// IMPORTAR FIREBASE //
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs, orderBy, query } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyCrv2BiybqKcI8cLsm-3qt8u_FgKf-QY8U",
    authDomain: "nexa-db-93fdd.firebaseapp.com",
    projectId: "nexa-db-93fdd",
    storageBucket: "nexa-db-93fdd.appspot.com",
    messagingSenderId: "1011655429895",
    appId: "1:1011655429895:web:cfc1dc4a57776b64febfa2",
    measurementId: "G-EB761FYEX0"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ===== CREAR NUEVO PACIENTE ===== //
document.getElementById('addPatientForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const clinicaActual = localStorage.getItem('clinicaConectada');
    const pacientesRef = collection(db, "clinicasID", clinicaActual, "pacientes");

    // === Añadir ID +1 cada create//
    const q = query(pacientesRef, orderBy("id", "desc"));
    const docsSnap = await getDocs(q);

    let nuevoId = 1;
    if (!docsSnap.empty) {
        nuevoId = docsSnap.docs[0].data().id + 1;
    }

    const newPatient = {
        id: nuevoId,
        nombre: document.getElementById('input_name').value,
        apellidos: document.getElementById('input_subname').value,
        genero: document.getElementById('genero').value,
        email: document.getElementById('input_email').value,
        telefono: document.getElementById('input_phone').value,
        telefono_2: document.getElementById('input_phone_2').value,
        fecha_nacimiento: convertirFechaAInput(document.getElementById('input_date').value),
        direccion: document.getElementById('input_address').value,
        localidad: document.getElementById('input_locality').value,
        medicacion_actual: document.getElementById('medicacion_actual').value,
        observaciones: document.getElementById('observaciones').value
    };

    try {
        await addDoc(pacientesRef, newPatient);

        alert("Paciente añadido correctamente.");
        console.log("Nuevo paciente creado:", newPatient); // Añade al paciente

        document.getElementById('addPatientForm').reset();

    } catch (error) {
        console.error("Error al añadir paciente:", error);
        alert("Hubo un problema al añadir el paciente.");
    }
});

// GUARDADO DE FECHA DD-MM-AAAA //
function convertirFechaAInput(fechaStr) {
    if (!fechaStr) return "";

    const partes = fechaStr.split("-");
    if (partes.length !== 3) return "";

    const [dia, mes, año] = partes;
    return `${año}-${mes}-${dia}`;
}