// == LOGIN == //
const usuario = localStorage.getItem('usuarioConectado');
const clinicaActual = localStorage.getItem('clinicaConectada');

if (!usuario || !clinicaActual) {
    window.location.href = "../index.html";
}

// Conversor de nombres
const nombresClinicas = {
    "clinicaSantaMaria": "&nbsp;CLÍNICA SANTA MARIA",
    "clinicaOctubreMd": "&nbsp;CLÍNICA OCTUBRE MADRID"
};

// Mostrar clínica conectada (estética)
document.getElementById('clinica-info').innerHTML = `
  <i class="fa-solid fa-wifi" style="color: #63E6BE;"></i>
  ${nombresClinicas[clinicaActual] || clinicaActual}
`;


// IMPORTAR FIREBASE
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyCrv2BiybqKcI8cLsm-3qt8u_FgKf-QY8U",
    authDomain: "nexa-db-93fdd.firebaseapp.com",
    projectId: "nexa-db-93fdd",
    storageBucket: "nexa-db-93fdd.appspot.com",
    messagingSenderId: "1011655429895",
    appId: "1:1011655429895:web:cfc1dc4a57776b64febfa2",
    measurementId: "G-EB761FYEX0"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// == LLAMADA A PACIENTES DE FIREBASE == //
async function getPacientes() {
    try {
        // Leer pacientes dentro de la clínica actual
        const querySnapshot = await getDocs(
            collection(db, "clinicasID", clinicaActual, "pacientes")
        );

        const pacientes = querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        displayPatients(pacientes);
    } catch (error) {
        console.error("Error al obtener pacientes:", error);
    }
}

getPacientes();

// TABLA PARA VER PACIENTES //
// fetch('http://localhost:4000/pacientes')
//     .then(response => response.json())
//     .then(data => displayPatients(data))
//     .catch(error => console.error('Error:', error));

function displayPatients(data) {
    const tableBody = document.getElementById('pacienteTableBody');
    tableBody.innerHTML = '';
    const limitedData = data.slice(0, 9); // Límite de 8 filas
    limitedData.forEach(pacientes => {
        const row = document.createElement('tr');
        row.innerHTML = ` 
                <td>${pacientes.id}</td> 
                <td class="marked">${pacientes.nombre}</td> 
                <td>${pacientes.apellidos}</td> 
                <td>${pacientes.fecha_nacimiento}</td> 
                <td>${pacientes.telefono}</td> 
                <td>${pacientes.localidad}</td> 
                <td class="sx"><i class='icons fa-solid fa-book' data-id="${pacientes.id}"></i></td>
            `;
        tableBody.appendChild(row);
    });

    // CONECTOR PARA MODIFICAR EL PACIENTE // 
    const tdElements = document.querySelectorAll('.fa-book');
    tdElements.forEach(td => {
        td.addEventListener('click', function () {
            const pacienteId = td.getAttribute('data-id');
            redirectToUpdatePacientePage(pacienteId);
        });
    });

    document.getElementById('totalResults').textContent = 'Resultados totales: ' + data.length;
}

function redirectToUpdatePacientePage(pacienteId) {
    window.location.href = `actualizar_paciente.html?id=${pacienteId}`;
}

// BARRA DE BÚSQUEDA DE PACIENTES POR NOMBRE //
window.searchClient = async function() {
    const searchInputEl = document.getElementById('searchInput');
    if (!searchInputEl) return;

    const searchInput = searchInputEl.value.toLowerCase();
    const clinicaActual = localStorage.getItem('clinicaConectada');
    if (!clinicaActual) return;

    try {
        // Leer todos los pacientes de la clínica actual
        const querySnapshot = await getDocs(
            collection(db, "clinicasID", clinicaActual, "pacientes")
        );

        const pacientes = querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        // Filtrar por nombre o apellidos
        const filteredData = pacientes.filter(paciente =>
            paciente.nombre.toLowerCase().includes(searchInput) ||
            paciente.apellidos.toLowerCase().includes(searchInput) ||
            paciente.localidad.toLowerCase().includes(searchInput)
        );

        displayPatients(filteredData);
    } catch (error) {
        console.error("Error al buscar pacientes:", error);
    }
};
// Posible busqueda directa
document.getElementById('searchInput').addEventListener('input', searchClient);

// CREAR NUEVO PACIENTE //
document.getElementById('addPatientForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const nombre = document.getElementById('input_name').value;
    const apellidos = document.getElementById('input_subname').value;
    const genero = document.getElementById('genero').value;
    const email = document.getElementById('input_email').value;
    const telefono = document.getElementById('input_phone').value;
    const telefono_2 = document.getElementById('input_phone_2').value;
    const fechaNacimiento = document.getElementById('input_date').value;
    const direccion = document.getElementById('input_address').value;
    const localidad = document.getElementById('input_locality').value;
    const alergias = document.getElementById('alergias').value;
    const medicacion_actual = document.getElementById("medicacion_actual").value;
    const enfermedades_cronicas = document.getElementById("enfermedades_cronicas").value;
    const cirugias_previas = document.getElementById("cirugias_previas").value;
    const vacunas_recientes = document.getElementById("vacunas_recientes").value;
    const antecedentes_familiares = document.getElementById("antecedentes_familiares").value;


    const newPatient = {
        nombre: nombre,
        apellidos: apellidos,
        genero: genero,
        email: email,
        telefono: telefono,
        telefono_2: telefono_2,
        fecha_nacimiento: fechaNacimiento,
        direccion: direccion,
        localidad: localidad,
        alergias: alergias,
        medicacion_actual: medicacion_actual,
        enfermedades_cronicas: enfermedades_cronicas,
        cirugias_previas: cirugias_previas,
        vacunas_recientes: vacunas_recientes,
        antecedentes_familiares: antecedentes_familiares
    };

    fetch('http://localhost:4000/pacientes', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newPatient)
    })
        .then(response => response.json())
        .then(data => {
            console.log('Nuevo paciente añadido:', data);
            alert('El paciente ha sido añadido con éxito.');
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Hubo un problema al añadir el paciente.');
        });
});

// SELECCION DE GÉNERO //
function changeImage() {
    const genderSelect = document.getElementById('genero');
    const genderImage = document.getElementById('genderImage');
    const selectedGender = genderSelect.value;

    if (selectedGender === 'hombre') {
        genderImage.src = '../assets/hombre.png';
    } else if (selectedGender === 'mujer') {
        genderImage.src = '../assets/mujer_2.png';
    };
};

// BOTON SALIR FUNCTION
document.getElementById('salir-btn').addEventListener('click', function () {
    document.getElementById('confirmacion-salida').style.display = 'flex';
});

document.getElementById('cerrar-btn').addEventListener('click', function () {
    window.location.href = '../index.html';
});

document.getElementById('mantener-btn').addEventListener('click', function () {
    document.getElementById('confirmacion-salida').style.display = 'none';
});